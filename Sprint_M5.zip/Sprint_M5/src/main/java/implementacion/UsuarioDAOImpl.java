package implementacion;

import conexion.Conexion;
import interfaces.IUsuario;
import models.TipoUsuario;
import models.Usuario;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAOImpl implements IUsuario {


    //En este método tomamos el objeto "Usuario", recopilamos su información y lo insertamos devuelta en una tabla de datos "usuarios".//
    //Por ultimo, si la operación es verdadera devuelve "true" y "false" si hubo un error.//
    @Override
    public boolean guardarUsuario(Usuario usuario) {
        boolean registrar = false;
        Statement stm = null;
        Connection conn = null;

        String sql = "INSERT INTO usuarios(nombre,contrasenia,tipo) values ('"+
                usuario.getNombre()+"','"+usuario.getContrasenia()+"','"+usuario.getTipo()+ "')";
        try{
            conn = Conexion.getConnection();
            stm = conn.createStatement();
            stm.execute(sql);
            registrar = true;
            stm.close();
            conn.close();
        }catch (SQLException e){
            System.out.println("Error : clase UsuarioDAOImpl en el método guardarUsuario");
            e.printStackTrace();
        }
        return registrar;
    }


    //En el siguiente metodo ejecutamos una consulta SQL para captar todos los registros de la tabla "usuarios" para//
    // crear objetos "Usuario" con la informacion conseguida y los agregamos en una lista que devolvemos como resultado.//
    @Override
    public List<Usuario> listarUsuario() {
        Statement stm = null;
        Connection conn = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM usuarios ORDER BY id";

        List<Usuario> listaUsuarios = new ArrayList<>();

        try{
            conn = Conexion.getConnection();
            stm = conn.createStatement();
            rs  = stm.executeQuery(sql);

            while(rs.next()){
                Usuario usuario = new Usuario();

                usuario.setId(rs.getInt(1));
                usuario.setNombre(rs.getString(2));
                usuario.setContrasenia(rs.getString(3));
                usuario.setTipo(TipoUsuario.valueOf(rs.getString(4)));

                listaUsuarios.add(usuario);
            }

            rs.close();
            stm.close();
            conn.close();

        }catch (SQLException e){
            System.out.println("Error : clase UsuarioDAOImpl en el método listarUsuario");
            e.printStackTrace();
        }

        return listaUsuarios;
    }


    //En el metodo siguiente ejecutamos una consulta SQL para realizar una busqueda del usuario en la base de datos según su ID,//
    // así, creamos un objeto "Usuario" con la información recopilada y lo devolvemos como resultado. No obstante, si el ID no es//
    // encontrado se retorna un metodo "null".//
    @Override
    public Usuario obtenerUsuarioPorId(int id) {

        Statement stm = null;
        Connection conn = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM usuarios WHERE id=" + id;

        Usuario usuario = null;

        try {
            conn = Conexion.getConnection();
            stm = conn.createStatement();
            rs = stm.executeQuery(sql);

            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getInt(1));
                usuario.setNombre(rs.getString(2));
                usuario.setContrasenia(rs.getString(3));
                usuario.setTipo(TipoUsuario.valueOf(rs.getString(4)));
                // Agregar más atributos del usuario según su estructura en la base de datos
            }

            rs.close();
            stm.close();
            conn.close();

        } catch (SQLException e) {
            System.out.println("Error: clase UsuarioDAOImpl en el método obtenerUsuarioPorId");
            e.printStackTrace();
        }

        return usuario;
    }


    //Por último, este metodo toma un objeto "Usuario", recopila la informacion actualizada y actualiza el registro del usuario//
    // en la tabla de la base de datos nombrada "usuarios". Finalmente, si la operación de actualización es exitosa, retorná un "true"//
    // y, si sucede un error, regresará un "false" junto con el menjase correspondiente.//
    @Override
    public boolean actualizarUsuario(Usuario usuario) {
        boolean modificar = false;
        Statement stm = null;
        Connection con = null;

        String sql = "UPDATE usuarios SET nombre='" + usuario.getNombre() + "', contrasenia='" + usuario.getContrasenia() + "', tipo='" + usuario.getTipo() + "' WHERE id=" + usuario.getId();

        try{
            con = Conexion.getConnection();
            stm = con.createStatement();
            stm.execute(sql);
            modificar = true;
            stm.close();
            con.close();

        }catch (SQLException e){
            System.out.println("Error : clase UsuarioDAOImpl en el método modificar");
            e.printStackTrace();
        }

        return modificar;
    }


}

