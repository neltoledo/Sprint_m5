package controller;

import implementacion.UsuarioDAOImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.TipoUsuario;
import models.Usuario;

import java.io.IOException;

/**
 * Servlet implementation class GuardarCambiosUsuario
 */
@WebServlet(name = "GuardarCambiosUsuario", value = "/GuardarCambiosUsuario")
public class GuardarCambiosUsuario extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl();

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GuardarCambiosUsuario() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = Integer.parseInt(request.getParameter("id"));
        String nombre = request.getParameter("nombre");
        String contrasenia = request.getParameter("contrasenia");
        TipoUsuario tipoUsuario = TipoUsuario.valueOf(request.getParameter("tipoUsuario"));

        Usuario usuarioActualizado = new Usuario(userId, nombre, contrasenia, tipoUsuario);

        if(usuarioDAO.actualizarUsuario(usuarioActualizado)){
            System.out.println("Usuario actualizado");
        }

        response.sendRedirect("ListadoUsuarios");
    }

}
