package models;

public class Contacto {

    private String nombre;
    private String correo;
    private String comentario;

    public Contacto() {
    }

    public Contacto(String nombre, String correo, String comentario) {
        this.nombre = nombre;
        this.correo = correo;
        this.comentario = comentario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    @Override
    public String toString() {
        return "Contacto \n" +
                "nombre: '" + nombre + '\'' +
                " correo: '" + correo + '\'' +
                " comentario: '" + comentario + '\'';
    }
}
