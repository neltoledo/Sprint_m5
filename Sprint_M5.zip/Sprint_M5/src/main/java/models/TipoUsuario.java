package models;

public enum TipoUsuario {
    Cliente,Profesional,Administrativo;
}
